import BioQuestWebsite from "../bio-quest-website"

export default function Home() {
  return <BioQuestWebsite />
}

